#include <iostream>

int main()
{
	std::cout << "My name is Tony Czajka.\n";
	std::cout << "I am a Computer Engineering Major.\n";
	std::cout << "My hobbies are:\n";
	std::cout << "\tPlaying Spikeball\n";
	std::cout << "\tHanging out with friends\n";
	std::cout << "\tPlaying video games\n";
	std::cout << "\tRiding my bike\n";
	std::cout << "Goodbye\n";
}

